# CleanComments
Plugin which remove html formatting from comments
