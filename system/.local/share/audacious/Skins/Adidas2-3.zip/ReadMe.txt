AdidasAmp by $teven - wilee.@ix.netcom.com

The logo of adidas is copyrighted and I must mention that I
got the three stipe from adidas and adidas.com and they 
have copyrights to it.

=)>