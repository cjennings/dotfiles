Winamp Skin #001: deviantAMP
by sasso					July 15, 2001
_________________________________________________________________________

Notes: This is my first stab at a winamp skin, and I used the graphical elements of the graphic community website http://www.deviantart.com for my ideas. I hope you like it, and I plan on making more in the future, which will be posted at deviantART and at my own website, http://www.metadream.com.
_________________________________________________________________________

Thanks,
	sasso - sasso@metadream.com - ICQ: 95883382
	metadream.com - sasso.deviantart.com